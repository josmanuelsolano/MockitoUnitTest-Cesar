package com.softtek.java.academy.test;

public class NumbersChecker {
	
	public boolean isOdd(int n){
		if(n % 2 != 0){
			return true;
		}else{
			return false;
		}
	}

}
